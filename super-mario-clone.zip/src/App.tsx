/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useRef, useState } from 'react';

// --- Constants ---
const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;
const GRAVITY = 0.5;
const JUMP_FORCE = -12;
const PLAYER_SPEED = 5;
const TILE_SIZE = 40;

// --- Types ---
interface Vector {
  x: number;
  y: number;
}

interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

// --- Game Classes ---

class Player implements Rect {
  pos: Vector;
  vel: Vector;
  width: number;
  height: number;
  onGround: boolean;
  color: string;

  get x() { return this.pos.x; }
  get y() { return this.pos.y; }

  constructor(x: number, y: number) {
    this.pos = { x, y };
    this.vel = { x: 0, y: 0 };
    this.width = 30;
    this.height = 40;
    this.onGround = false;
    this.color = '#ff4444'; // Mario Red
  }

  update(keys: Record<string, boolean>, platforms: Platform[]) {
    // Horizontal movement
    if (keys['ArrowLeft'] || keys['a']) {
      this.vel.x = -PLAYER_SPEED;
    } else if (keys['ArrowRight'] || keys['d']) {
      this.vel.x = PLAYER_SPEED;
    } else {
      this.vel.x = 0;
    }

    // Jump
    if ((keys['ArrowUp'] || keys['w'] || keys[' ']) && this.onGround) {
      this.vel.y = JUMP_FORCE;
      this.onGround = false;
    }

    // Apply gravity
    this.vel.y += GRAVITY;

    // Apply velocity
    this.pos.x += this.vel.x;
    this.handleHorizontalCollisions(platforms);
    
    this.pos.y += this.vel.y;
    this.handleVerticalCollisions(platforms);

    // Screen boundaries (left)
    if (this.pos.x < 0) this.pos.x = 0;
  }

  handleHorizontalCollisions(platforms: Platform[]) {
    for (const platform of platforms) {
      if (this.collidesWith(platform)) {
        if (this.vel.x > 0) {
          this.pos.x = platform.x - this.width;
        } else if (this.vel.x < 0) {
          this.pos.x = platform.x + platform.width;
        }
      }
    }
  }

  handleVerticalCollisions(platforms: Platform[]) {
    this.onGround = false;
    for (const platform of platforms) {
      if (this.collidesWith(platform)) {
        if (this.vel.y > 0) {
          this.pos.y = platform.y - this.height;
          this.vel.y = 0;
          this.onGround = true;
        } else if (this.vel.y < 0) {
          this.pos.y = platform.y + platform.height;
          this.vel.y = 0;
        }
      }
    }
  }

  collidesWith(rect: Rect) {
    return (
      this.pos.x < rect.x + rect.width &&
      this.pos.x + this.width > rect.x &&
      this.pos.y < rect.y + rect.height &&
      this.pos.y + this.height > rect.y
    );
  }

  draw(ctx: CanvasRenderingContext2D, cameraX: number) {
    ctx.fillStyle = this.color;
    ctx.fillRect(this.pos.x - cameraX, this.pos.y, this.width, this.height);
    
    // Eyes
    ctx.fillStyle = 'white';
    const eyeOffset = this.vel.x >= 0 ? 15 : 5;
    ctx.fillRect(this.pos.x - cameraX + eyeOffset, this.pos.y + 10, 5, 5);
  }
}

class Enemy implements Rect {
  pos: Vector;
  vel: Vector;
  width: number;
  height: number;
  color: string;
  dead: boolean;
  type: 'walker' | 'flyer' | 'shooter' = 'walker';

  get x() { return this.pos.x; }
  get y() { return this.pos.y; }

  constructor(x: number, y: number) {
    this.pos = { x, y };
    this.vel = { x: -2, y: 0 };
    this.width = 30;
    this.height = 30;
    this.color = '#8b4513'; // Goomba Brown
    this.dead = false;
  }

  update(platforms: Platform[], player?: Player, onShoot?: (p: Projectile) => void) {
    if (this.dead) return;

    if (this.type === 'walker') {
      this.vel.y += GRAVITY;
      this.pos.x += this.vel.x;
      
      // Simple horizontal collision and wall bounce
      for (const platform of platforms) {
        if (this.collidesWith(platform)) {
          if (this.vel.x > 0) {
            this.pos.x = platform.x - this.width;
            this.vel.x *= -1;
          } else if (this.vel.x < 0) {
            this.pos.x = platform.x + platform.width;
            this.vel.x *= -1;
          }
        }
      }

      this.pos.y += this.vel.y;
      // Vertical collision
      for (const platform of platforms) {
        if (this.collidesWith(platform)) {
          if (this.vel.y > 0) {
            this.pos.y = platform.y - this.height;
            this.vel.y = 0;
          }
        }
      }
    }
  }

  collidesWith(rect: Rect) {
    return (
      this.pos.x < rect.x + rect.width &&
      this.pos.x + this.width > rect.x &&
      this.pos.y < rect.y + rect.height &&
      this.pos.y + this.height > rect.y
    );
  }

  draw(ctx: CanvasRenderingContext2D, cameraX: number) {
    if (this.dead) return;
    ctx.fillStyle = this.color;
    ctx.fillRect(this.pos.x - cameraX, this.pos.y, this.width, this.height);
    
    // Angry eyes
    ctx.fillStyle = 'white';
    ctx.fillRect(this.pos.x - cameraX + 5, this.pos.y + 5, 5, 5);
    ctx.fillRect(this.pos.x - cameraX + 20, this.pos.y + 5, 5, 5);
  }
}

class FlyingEnemy extends Enemy {
  startY: number;
  angle: number = 0;

  constructor(x: number, y: number) {
    super(x, y);
    this.type = 'flyer';
    this.color = '#9370db'; // Purple
    this.startY = y;
    this.vel.x = -1.5;
  }

  update() {
    if (this.dead) return;
    this.pos.x += this.vel.x;
    this.angle += 0.05;
    this.pos.y = this.startY + Math.sin(this.angle) * 50;
  }

  draw(ctx: CanvasRenderingContext2D, cameraX: number) {
    if (this.dead) return;
    super.draw(ctx, cameraX);
    // Wings
    ctx.fillStyle = 'white';
    ctx.fillRect(this.pos.x - cameraX - 5, this.pos.y + 10, 5, 10);
    ctx.fillRect(this.pos.x - cameraX + this.width, this.pos.y + 10, 5, 10);
  }
}

class ShootingEnemy extends Enemy {
  shootTimer: number = 0;
  shootInterval: number = 120;

  constructor(x: number, y: number) {
    super(x, y);
    this.type = 'shooter';
    this.color = '#2f4f4f'; // Dark Slate Gray
    this.height = 40;
  }

  update(platforms: Platform[], player: Player, onShoot: (p: Projectile) => void) {
    if (this.dead) return;
    
    // Gravity for shooters too
    this.vel.y += GRAVITY;
    this.pos.y += this.vel.y;
    for (const platform of platforms) {
      if (this.collidesWith(platform)) {
        if (this.vel.y > 0) {
          this.pos.y = platform.y - this.height;
          this.vel.y = 0;
        }
      }
    }

    this.shootTimer++;
    if (this.shootTimer >= this.shootInterval) {
      this.shootTimer = 0;
      const dx = player.pos.x - this.pos.x;
      const dy = (player.pos.y + player.height/2) - (this.pos.y + this.height/2);
      const dist = Math.sqrt(dx * dx + dy * dy);
      const speed = 4;
      onShoot(new Projectile(
        this.pos.x + this.width / 2,
        this.pos.y + this.height / 2,
        (dx / dist) * speed,
        (dy / dist) * speed
      ));
    }
  }

  draw(ctx: CanvasRenderingContext2D, cameraX: number) {
    if (this.dead) return;
    super.draw(ctx, cameraX);
    // Cannon eye
    ctx.fillStyle = 'black';
    ctx.fillRect(this.pos.x - cameraX + 10, this.pos.y + 15, 10, 10);
  }
}

class Projectile implements Rect {
  x: number;
  y: number;
  width: number = 10;
  height: number = 10;
  velX: number;
  velY: number;
  color: string = '#ff00ff';

  constructor(x: number, y: number, velX: number, velY: number) {
    this.x = x;
    this.y = y;
    this.velX = velX;
    this.velY = velY;
  }

  update() {
    this.x += this.velX;
    this.y += this.velY;
  }

  draw(ctx: CanvasRenderingContext2D, cameraX: number) {
    ctx.fillStyle = this.color;
    ctx.beginPath();
    ctx.arc(this.x - cameraX + 5, this.y + 5, 5, 0, Math.PI * 2);
    ctx.fill();
  }

  collidesWith(rect: Rect) {
    return (
      this.x < rect.x + rect.width &&
      this.x + this.width > rect.x &&
      this.y < rect.y + rect.height &&
      this.y + this.height > rect.y
    );
  }
}

class Coin implements Rect {
  x: number;
  y: number;
  width: number = 20;
  height: number = 20;
  collected: boolean = false;
  color: string = '#ffd700'; // Gold

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
  }

  draw(ctx: CanvasRenderingContext2D, cameraX: number) {
    if (this.collected) return;
    
    ctx.fillStyle = this.color;
    ctx.beginPath();
    ctx.arc(this.x - cameraX + 10, this.y + 10, 10, 0, Math.PI * 2);
    ctx.fill();
    
    // Shine
    ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
    ctx.beginPath();
    ctx.arc(this.x - cameraX + 7, this.y + 7, 3, 0, Math.PI * 2);
    ctx.fill();
    
    // Border
    ctx.strokeStyle = '#b8860b'; // Dark Goldenrod
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  collidesWith(rect: Rect) {
    if (this.collected) return false;
    return (
      this.x < rect.x + rect.width &&
      this.x + this.width > rect.x &&
      this.y < rect.y + rect.height &&
      this.y + this.height > rect.y
    );
  }
}

const playCoinSound = () => {
  try {
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();

    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(987.77, audioCtx.currentTime); // B5
    oscillator.frequency.exponentialRampToValueAtTime(1318.51, audioCtx.currentTime + 0.1); // E6

    gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);

    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    oscillator.start();
    oscillator.stop(audioCtx.currentTime + 0.2);
  } catch (e) {
    console.warn('Audio context not allowed yet or not supported');
  }
};

class Platform implements Rect {
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  type: 'ground' | 'block' | 'pipe';

  constructor(x: number, y: number, width: number, height: number, type: 'ground' | 'block' | 'pipe' = 'ground') {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    this.type = type;
    
    switch (type) {
      case 'ground': this.color = '#228b22'; break; // Forest Green
      case 'block': this.color = '#ffa500'; break; // Orange
      case 'pipe': this.color = '#006400'; break; // Dark Green
    }
  }

  draw(ctx: CanvasRenderingContext2D, cameraX: number) {
    ctx.fillStyle = this.color;
    ctx.fillRect(this.x - cameraX, this.y, this.width, this.height);
    
    // Add some texture/border
    ctx.strokeStyle = 'rgba(0,0,0,0.2)';
    ctx.strokeRect(this.x - cameraX, this.y, this.width, this.height);
  }
}

class Flag {
  x: number;
  y: number;
  width: number;
  height: number;

  constructor(x: number) {
    this.x = x;
    this.y = CANVAS_HEIGHT - TILE_SIZE - 200;
    this.width = 10;
    this.height = 200;
  }

  draw(ctx: CanvasRenderingContext2D, cameraX: number) {
    // Pole
    ctx.fillStyle = '#cccccc';
    ctx.fillRect(this.x - cameraX, this.y, this.width, this.height);
    
    // Flag
    ctx.fillStyle = '#ff0000';
    ctx.beginPath();
    ctx.moveTo(this.x - cameraX + this.width, this.y);
    ctx.lineTo(this.x - cameraX + this.width + 40, this.y + 20);
    ctx.lineTo(this.x - cameraX + this.width, this.y + 40);
    ctx.fill();
  }

  collidesWith(rect: Rect) {
    return (
      rect.x < this.x + this.width &&
      rect.x + rect.width > this.x &&
      rect.y < this.y + this.height &&
      rect.y + rect.height > this.y
    );
  }
}

// --- Main App Component ---

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<'playing' | 'won' | 'lost'>('playing');
  const [score, setScore] = useState(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Game state
    const player = new Player(100, 400);
    const platforms: Platform[] = [
      // Ground
      new Platform(0, CANVAS_HEIGHT - TILE_SIZE, 3000, TILE_SIZE, 'ground'),
      // Some platforms
      new Platform(300, 450, 120, 40, 'block'),
      new Platform(500, 350, 120, 40, 'block'),
      new Platform(700, 450, 120, 40, 'block'),
      new Platform(900, 300, 200, 40, 'block'),
      // Pipes
      new Platform(1200, CANVAS_HEIGHT - TILE_SIZE - 80, 60, 80, 'pipe'),
      new Platform(1600, CANVAS_HEIGHT - TILE_SIZE - 120, 60, 120, 'pipe'),
      // More blocks
      new Platform(1400, 350, 40, 40, 'block'),
      new Platform(1440, 350, 40, 40, 'block'),
      new Platform(1480, 350, 40, 40, 'block'),
    ];

    const enemies: Enemy[] = [
      new Enemy(600, 400),
      new Enemy(1000, 200),
      new Enemy(1500, 400),
      new Enemy(2000, 400),
      new FlyingEnemy(800, 200),
      new FlyingEnemy(1800, 150),
      new ShootingEnemy(1300, 400),
      new ShootingEnemy(2200, 400),
    ];

    const projectiles: Projectile[] = [];
    const coins: Coin[] = [
      new Coin(400, 400),
      new Coin(440, 400),
      new Coin(480, 400),
      new Coin(550, 300),
      new Coin(750, 400),
      new Coin(950, 250),
      new Coin(1420, 300),
      new Coin(1460, 300),
      new Coin(1500, 300),
      new Coin(1700, 450),
      new Coin(2100, 450),
      new Coin(2500, 450),
    ];
    const flag = new Flag(2800);

    const keys: Record<string, boolean> = {};
    let cameraX = 0;
    let animationFrameId: number;

    const handleKeyDown = (e: KeyboardEvent) => { keys[e.key] = true; };
    const handleKeyUp = (e: KeyboardEvent) => { keys[e.key] = false; };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    const gameLoop = () => {
      if (gameState !== 'playing') return;

      // Update
      player.update(keys, platforms);

      // Projectile logic
      for (let i = projectiles.length - 1; i >= 0; i--) {
        const p = projectiles[i];
        p.update();
        
        // Collision with player
        if (p.collidesWith(player)) {
          setGameState('lost');
        }

        // Remove if off screen or too far
        if (Math.abs(p.x - player.pos.x) > 1000) {
          projectiles.splice(i, 1);
        }
      }

      // Enemy logic
      enemies.forEach(enemy => {
        enemy.update(platforms, player, (p) => projectiles.push(p));
        
        // Collision with player
        if (!enemy.dead && player.collidesWith(enemy)) {
          // Stomp check
          if (player.vel.y > 0 && player.pos.y + player.height < enemy.pos.y + 15) {
            enemy.dead = true;
            player.vel.y = -8; // Bounce
            setScore(s => s + 100);
          } else {
            // Player hit
            setGameState('lost');
          }
        }
      });

      // Flag collision
      if (flag.collidesWith(player)) {
        setGameState('won');
      }

      // Coin collision
      coins.forEach(coin => {
        if (!coin.collected && coin.collidesWith(player)) {
          coin.collected = true;
          setScore(s => s + 50);
          playCoinSound();
        }
      });

      // Camera follow
      const targetCameraX = player.pos.x - CANVAS_WIDTH / 3;
      cameraX += (targetCameraX - cameraX) * 0.1;
      if (cameraX < 0) cameraX = 0;

      // Draw
      ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Background (Sky)
      ctx.fillStyle = '#87ceeb';
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Draw entities
      platforms.forEach(p => p.draw(ctx, cameraX));
      coins.forEach(c => c.draw(ctx, cameraX));
      enemies.forEach(e => e.draw(ctx, cameraX));
      projectiles.forEach(p => p.draw(ctx, cameraX));
      flag.draw(ctx, cameraX);
      player.draw(ctx, cameraX);

      animationFrameId = requestAnimationFrame(gameLoop);
    };

    gameLoop();

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      cancelAnimationFrame(animationFrameId);
    };
  }, [gameState]);

  const restartGame = () => {
    setGameState('playing');
    setScore(0);
  };

  return (
    <div className="min-h-screen bg-neutral-900 flex flex-col items-center justify-center p-4 font-sans">
      <div className="mb-4 text-white flex justify-between w-full max-w-[800px] items-end">
        <div>
          <h1 className="text-3xl font-bold tracking-tighter uppercase italic">Super Mario Clone</h1>
          <p className="text-neutral-400 text-sm">Use Arrow Keys or WASD to Move & Jump</p>
        </div>
        <div className="text-right">
          <p className="text-xs uppercase tracking-widest text-neutral-500">Score</p>
          <p className="text-2xl font-mono">{score.toString().padStart(6, '0')}</p>
        </div>
      </div>

      <div className="relative border-4 border-neutral-800 rounded-lg overflow-hidden shadow-2xl">
        <canvas
          ref={canvasRef}
          width={CANVAS_WIDTH}
          height={CANVAS_HEIGHT}
          className="bg-sky-400 block"
        />

        {gameState !== 'playing' && (
          <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-white backdrop-blur-sm">
            <h2 className="text-6xl font-black uppercase italic mb-4 tracking-tighter">
              {gameState === 'won' ? 'Course Clear!' : 'Game Over'}
            </h2>
            <p className="text-xl mb-8 text-neutral-300">
              {gameState === 'won' ? `Final Score: ${score}` : 'Better luck next time!'}
            </p>
            <button
              onClick={restartGame}
              className="px-8 py-3 bg-white text-black font-bold uppercase tracking-widest hover:bg-neutral-200 transition-colors rounded-full"
            >
              Play Again
            </button>
          </div>
        )}
      </div>

      <div className="mt-8 grid grid-cols-3 gap-8 w-full max-w-[800px] text-neutral-500 text-xs uppercase tracking-widest">
        <div className="border-t border-neutral-800 pt-4">
          <p className="mb-1 text-neutral-400">Controls</p>
          <p>Arrows / WASD</p>
        </div>
        <div className="border-t border-neutral-800 pt-4">
          <p className="mb-1 text-neutral-400">Objective</p>
          <p>Reach the Red Flag</p>
        </div>
        <div className="border-t border-neutral-800 pt-4">
          <p className="mb-1 text-neutral-400">Enemies</p>
          <p>Jump to Stomp</p>
        </div>
      </div>
    </div>
  );
}
